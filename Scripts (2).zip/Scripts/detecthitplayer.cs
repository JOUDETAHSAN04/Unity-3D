﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class detecthitplayer : MonoBehaviour
{
    public GameObject player;
    public Slider healthbar;
    Animator anim;
    public string opponent;
    public AudioClip audioclip3;
    public AudioSource Source;
    public AudioClip audioclip4;
    public AudioClip audioclip5;
    private void Update()
    {
        anim = GetComponent<Animator>();
        Source = GetComponent<AudioSource>();

       // Source.PlayOneShot(audioclip5,20f);
    }

    private void OnTriggerEnter(Collider others)
    {

       /* if (others.gameObject.tag != opponent)//
        {
            print("khud pa atack");
            
        }
        if(others.gameObject.tag == opponent)
        {

            Source.PlayOneShot(audioclip3);
            healthbar.value -= 10;
        }
        
        else*/ if(others.gameObject.tag == opponent)
        {

            Source.PlayOneShot(audioclip3);
            healthbar.value -= 2;
        }

        if (healthbar.value <= 0)
        {
            print("player outt");
            anim.SetBool("playerdeath", true);
            Source.PlayOneShot(audioclip4);
            SceneManager.LoadScene("main");
            //anim.SetInteger("death", 1);
        }

    }
}
