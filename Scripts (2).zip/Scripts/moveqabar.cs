﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moveqabar : MonoBehaviour
{
    public GameObject myPrefab;
    public Animator anim;
  public GameObject tomb;
 public AudioClip audioclip5;
  public AudioSource Source;

    private void Awake()
    {
        Source = GetComponent<AudioSource>();
    }
    void Start()
    {
        anim = GetComponent<Animator>();
      //  Vector3 qabarheight = new Vector3(0, 0.66f, 0);
      //  Vector3 abc;
      //  abc = transform.position + qabarheight;
    }

    // Update is called once per frame
    void Update()
    {
        //Source.playOnAwake = true;
       

    }
    
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Sphere")
        {
            Source.PlayOneShot(audioclip5);
            anim.SetTrigger("moveqabar");
           // Source.PlayOneShot(audioclip2);
          
          Instantiate(myPrefab,transform.position, Quaternion.identity);
            print("hayee");
        }
    }

}