﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class detecthitenemy : MonoBehaviour
{
    public GameObject enemy;
    public Slider healthbars;
    Animator anim;
    public string opponent;//player
    public AudioClip audioclip2;
    public AudioSource Source;


     void Start()
    {
        Source = GetComponent<AudioSource>();
    }
    private void OnTriggerEnter(Collider other)
    {


         if(other.gameObject.tag =="Sphere")
        {
            healthbars.value -= 30;
        }

        if (healthbars.value <= 0)
        {

            enemy.GetComponent<Animator>().Play("enemydeath");

            Debug.Log("yeahhhh enemy died");
            Source.PlayOneShot(audioclip2);

            //uski awaaz nahi hai main axe dhoond rahi

            ///enemy death ka shorr a chheekh
        }
           // anim.SetInteger("enemydeath", 1);
      //  anim.SetInteger("death", 1);
    }
}
