﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class pickup : MonoBehaviour
{
    private int count;
    public Text countText;
    public int quotaTowin;
    public Text winText;

    // Start is called before the first frame update
    public AudioClip audioclip1;
    public AudioClip audioclip2;
    public AudioSource Source;
    public AudioSource Source2;
    private void Awake()
    {
       Source = GetComponent<AudioSource>();
        Source.PlayOneShot(audioclip2); 
    }
    public void SetCountText()
    {

        // Update the text field of our 'countText' variable
        countText.text = "Score: " + count.ToString();

        // Check if our 'count' is equal to or exceeded 12
        if (count >= quotaTowin)
        {
            // Set the text value of our 'winText'
            winText.text = "You Win!";
            SceneManager.LoadScene("menu");
            //  StartCoroutine(WaitForSceneLoad());

        }
    }

    void Start()
    {
        count = 0;

        // Run the SetCountText function to update the UI (see below)
        SetCountText();

        // Set the text property of our Win Text UI to an empty string, making the 'You Win' (game over message) blank
        winText.text = "";
    }

   
        // Update is called once per frame
        void Update()
        {
      //  transform.Rotate(new Vector3(0, 90, 0) * Time.deltaTime);
    }
     void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Sphere"))
        {
            return;

        }
       else if (other.gameObject.CompareTag("Pick Up"))
        {
            Source.PlayOneShot(audioclip1);
            print("hittttttt" + other.name);


            Source2.PlayOneShot(audioclip1);
            other.gameObject.SetActive(false);
            count++;
            SetCountText();
            // Make the other game object (the pick up) inactive, to make it disappear

            // Instantiate(explosion, transform.position, transform.rotation);

            //winText.text = "you lose";

            //   StartCoroutine(WaitForSceneLoad());
        }

         
    }
    private IEnumerator WaitForSceneLoad() //coroutine to add delay
    {
        yield return new WaitForSeconds(3);
        // SceneManager.Load("A Scene");
        SceneManager.LoadScene("menu", LoadSceneMode.Single);
    }
} 
