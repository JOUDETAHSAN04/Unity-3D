﻿using System.Collections;
using System.Collections.Generic;

using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;
public class followplayer : MonoBehaviour
{  public Slider healthbar;
    private NavMeshAgent Enemy;
    public GameObject vThirdPersonController;
    public float enemydistancerun ;
    public AudioClip audioclip4;
    public AudioSource Source;
    private Animator anim;
    // Start is called before the first frame update
    void Start()
    {
        Enemy = GetComponent<NavMeshAgent>();
        anim = GetComponent<Animator>();
       Source = GetComponent<AudioSource>();
    }

  
    void Update()
    {
        if (healthbar.value <= 0)
            return;

        //code for enemies to follow the player
        float distance = Vector3.Distance(transform.position, vThirdPersonController.transform.position);
        if (distance < enemydistancerun)
        {
            Vector3 dirtoplayer = transform.position - vThirdPersonController.transform.position;
            Vector3 newpos = transform.position - dirtoplayer;
            Enemy.SetDestination(newpos);
        }

        //play attack animation at a distance less than 5f
        if (distance < 5.0f)
        {

            Source.PlayOneShot(audioclip4);
            Debug.Log("attacking");
           
            anim.SetInteger("attack", 1);
        }
     

    }
   /* void playerdeath()//kahan call hua hai
    {
        Debug.Log(" ohhhhhhh  player died");

       player.GetComponent<Animator> ().Play ("playerdeath");
        //anim.SetInteger("death", 1);
    }
    */

}
