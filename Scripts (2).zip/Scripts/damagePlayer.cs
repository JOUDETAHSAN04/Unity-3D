﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class damagePlayer : MonoBehaviour
{
    public int playerHealth = 30;
   public int damage=10;
    // Start is called before the first frame update
    void Start()
    {
        print("printHealth");
    }

    private void OnCollisionEnter(Collision _collision)
    {
        if (_collision.gameObject.tag == "enemy")
        {

            playerHealth -= damage;
            print("ohhh enemyy" + playerHealth);

        }
    }
   

}
