﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class spawnenemies : MonoBehaviour
{
    public GameObject enemy;
    public int x;
    public int z;
    public int noofenemies;
    void Start()
    {
        StartCoroutine(spawnenemy());
    }
    IEnumerator spawnenemy()
    {
        while(noofenemies < 100)
        {
             x = Random.Range(-1200,-1600);
             z = Random.Range(400,700);
             Instantiate(enemy, new Vector3 (x,0.0f, z), Quaternion.identity);
             yield return new WaitForSeconds(2.0f);
             noofenemies += 1;

         


        }
    }
    private void onBecameInvisible()
    {
        Destroy(gameObject);
    }
}

  